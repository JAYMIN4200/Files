<?php

use App\Http\Controllers\FormController;
use App\Http\Controllers\AuthController;
use Faker\Guesser\Name;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

//AuthController
Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
Route::post('/login-store', [AuthController::class, 'loginstore'])->name('login.store');
Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
Route::post('/register-store', [AuthController::class, 'registerstore'])->name('register.store');

//FormController
Route::get('/add/{id?}', [FormController::class, 'add'])->name('form.add');
Route::post('form/store/{id?}', [FormController::class, 'store'])->name('form.store');
Route::get('form/list', [FormController::class, 'list'])->name('form.list');
Route::delete('form/delete/{id}', [FormController::class, 'delete'])->name('form.delete');
Route::get('/get-states/{country_id}', [FormController::class, 'getStates'])->name('form.state');
Route::get('/get-cities/{state_id}', [FormController::class, 'getCities'])->name('form.city');

