<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <title>Registration Form</title>
    <style>
        body {
            background-image: url('/images/22.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>

<body>
    <div class="bg-white text-center py-3">
        <h3 class="text-dark">Registration Form</h3>
    </div>
    <div class="col-md-10 d-flex justify-content-end py-3">
        <a href="<?php echo e(route('form.list')); ?>" class="btn btn-dark primary-btn">All Form Details</a>
    </div>
    <div class="container mt-3">
        <div class="card">
            <div class="card-header">
                <h2><?php echo e(isset($form->id) ? 'Edit Details' : 'Add Details'); ?></h2>
            </div>

            <div class="card-body">
                <form action="<?php echo e(route('form.store', isset($form->id) ? $form->id : null)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Name"
                            value="<?php echo e(old('name', isset($form->name) ? $form->name : '')); ?>" autocomplete="name"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="website">Website URL:</label>
                        <input type="url" class="form-control" id="website" name="website"
                            placeholder="Enter Website URL"
                            value="<?php echo e(old('website', isset($form->website) ? $form->website : '')); ?>" autocomplete="url"
                            required>
                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="number">Mobile Number:</label>
                        <input type="tel" class="form-control" id="number" name="number"
                            value="<?php echo e(old('number', isset($form->number) ? $form->number : '')); ?>"
                            placeholder="Enter Your Mobile Number" autocomplete="tel" required>
                    </div>

                    <div class="mb-3">
                        <label for="image">Upload Image:</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <label for="date">Birth Date:</label>
                        <input type="date" class="form-control" id="date" name="date"
                            value="<?php echo e(isset($form->date) ? $form->date : ''); ?>" autocomplete="bday" required>
                    </div>
                    <div class="mb-3">
                        <label for="hobbies">Hobbies:</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="hobbies[]" id="hobbyReading"
                                    value="reading" <?php echo e(in_array('reading', old('hobbies', isset($form->hobbies) ?
                                $form->hobbies : [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="hobbyReading">Reading</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="hobbies[]" id="hobbyLearning"
                                    value="learning" <?php echo e(in_array('learning', old('hobbies', isset($form->hobbies) ?
                                $form->hobbies : [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="hobbyLearning">Learning</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="hobbies[]" id="hobbyGaming"
                                    value="gaming" <?php echo e(in_array('gaming', old('hobbies', isset($form->hobbies) ?
                                $form->hobbies : [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="hobbyGaming">Gaming</label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="country">Country:</label>
                        <select id="country" name="country_id" class="form-control" autocomplete="country">
                            <option value="" disabled selected>Select Country</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>" <?php echo e(old('country_id', $form->country_id ?? '') ==
                                $country->id ? 'selected' : ''); ?>>
                                <?php echo e($country->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="state">State:</label>
                        <select id="state" name="state_id" class="form-control" autocomplete="state">
                            <option value="" disabled selected>Select State</option>
                            <?php if(isset($states) && !empty($states)): ?>
                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($state->id); ?>" <?php echo e(old('state_id', $form->state_id ?? '') == $state->id ?
                                'selected' : ''); ?>>
                                <?php echo e($state->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="city">City:</label>
                        <select id="city" name="city_id" class="form-control" autocomplete="city">
                            <option value="" disabled selected>Select City</option>
                            <?php if(isset($cities) && !empty($cities)): ?>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->id); ?>" <?php echo e(old('city_id', $form->city_id ?? '') == $city->id ?
                                'selected' : ''); ?>>
                                <?php echo e($city->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="budget">Budget:</label>
                        <input type="range" class="form-control" id="budget" name="budget" min="0" max="100000"
                            step="1000" value="<?php echo e(isset($form->budget) ? $form->budget : 0); ?>"
                            oninput="this.nextElementSibling.value = this.value" autocomplete="off">
                        <output><?php echo e(isset($form->budget) ? $form->budget : 0); ?></output>
                    </div>

                    <div class="mb-3">
                        <label for="gender">Gender:</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="genderMale" value="male"
                                    <?php echo e(old('gender', isset($form->gender) ? $form->gender : '') == 'male' ? 'checked' :
                                ''); ?> required>
                                <label class="form-check-label" for="genderMale">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="genderFemale"
                                    value="female" <?php echo e(old('gender', isset($form->gender) ? $form->gender : '') ==
                                'female' ? 'checked' : ''); ?> required>
                                <label class="form-check-label" for="genderFemale">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="genderOther"
                                    value="other" <?php echo e(old('gender', isset($form->gender) ? $form->gender : '') == 'other'
                                ? 'checked' : ''); ?> required>
                                <label class="form-check-label" for="genderOther">Other</label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="address">Address:</label>
                        <textarea class="form-control" id="address" name="address" rows="3"
                            placeholder="Enter Your Address"
                            required><?php echo e(old('address', isset($form->address) ? $form->address : '')); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Enter Your Password" autocomplete="new-password" required>
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation">Confirm Password:</label>
                        <input type="password" class="form-control" id="password_confirmation"
                            name="password_confirmation" placeholder="Confirm Your Password" autocomplete="new-password"
                            required>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-lg btn-primary btn-block">
                            <?php echo e(isset($form->id) ? 'Update' : 'Submit'); ?>

                        </button>
                    </div><br>
                    <div class="text-center">
                        <button type="reset" class="btn btn-lg btn-secondary btn-block">
                            Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });

        $(document).ready(function() {
            $('#state').prop('disabled', true);
            $('#city').prop('disabled', true);
            $('#country').change(function() {
                var country_id = $(this).val();
                if (country_id) {
                    $.ajax({
                        url: '/get-states/' + country_id,
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            $('#state').prop('disabled', false).empty().append('<option value="">Select State</option>');
                            $.each(data, function(index, state) {
                                $.each(state, function(index, val) {
                                    $('#state').append('<option value="' + val.id + '">' + val.name + '</option>');
                                });
                            });
                            $('#city').prop('disabled', true).empty().append('<option value="">Select City</option>');
                        },
                        error: function(xhr, status, error) {
                            console.log('AJAX Error:', xhr.responseText);
                        }
                    });
                } else {
                    $('#state').prop('disabled', true).empty().append('<option value="">Select State</option>');
                    $('#city').prop('disabled', true).empty().append('<option value="">Select City</option>');
                }
            });

            $('#state').change(function() {
                var state_id = $(this).val();
                if (state_id) {
                    $.ajax({
                        url: '/get-cities/' + state_id,
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            $('#city').prop('disabled', false).empty().append('<option value="">Select City</option>');
                            $.each(data, function(index, city) {
                                $.each(city, function(index, val) {
                                    $('#city').append('<option value="' + val.id + '">' + val.name + '</option>');
                                });
                            });
                        },
                        error: function(xhr, status, error) {
                            console.log('AJAX Error:', xhr.responseText);
                        }
                    });
                } else {
                    $('#city').prop('disabled', true).empty().append('<option value="">Select City</option>');
                }
            });
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\form\resources\views/form/add.blade.php ENDPATH**/ ?>