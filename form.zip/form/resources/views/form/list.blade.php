<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>All Forms</title>
    <style>
        body {
            background-image: url('/images/22.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            color: #ece6e6;
        }

        .tooltip-inner {
            background-color: #000000;
            color: #ece6e6;
            max-width: 500px !important;
            padding: 0.5rem;
        }

        td {
            max-width: 100px !important;
            max-height: 100px !important;
            font-weight: 400 !important;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            position: relative;
            padding: 1.5rem;
        }

        .table-wrapper {
            overflow-x: auto;
            width: 100%;
            height: 100%;
        }

        .table th,
        .table td {
            vertical-align: middle;
            text-align: center;
            white-space: nowrap;
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            height: 60px;
            line-height: 1.5;
        }

        .table img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            cursor: pointer;
        }

        .table .action-btns {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
        }

        .table .action-btns a,
        .table .action-btns button {
            border: none;
            background: none;
            cursor: pointer;
            padding: 0;
            font-size: 1.2rem;
        }

        .modal-body img {
            max-width: 50%;
            max-height: 50vh;
            object-fit: contain;
        }

        .modal-dialog.custom-size {
            max-width: 100%%;
        }

        .table .action-btns button {
            color: #dc3545;
        }

        .table .action-btns a {
            color: #1478dc;
        }
    </style>
</head>

<body>
    <div class="bg-white text-center py-3">
        <h3 class="text-dark">All Form Details</h3>
    </div>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-end py-3">
                <a href="{{ route('form.add') }}" class="btn btn-dark">Add New Details</a>
            </div>
        </div>

        @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
        @endif

        <div class="card">
            <div class="card-header">
                <h2 class="text-dark"> All Details</h2>
            </div>
            <div class="card-body table-wrapper">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th class="name">Name</th>
                            <th class="image">Image</th>
                            <th class="website">Website</th>
                            <th class="number">Mobile No</th>
                            <th class="budget">Budget</th>
                            <th class="date">Birth Date</th>
                            <th class="hobbies">Hobbies</th>
                            <th class="country_id">Country</th>
                            <th class="state_id">State</th>
                            <th class="city_id">City</th>
                            <th class="gender">Gender</th>
                            <th class="address">Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($forms->isNotEmpty())
                        @foreach ($forms as $form)
                        <tr>
                            <td style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top">
                                {{ $form->id }}</td>

                            <td class="name" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->name }}">
                                {{ $form->name }}</td>

                            <td class="image" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top">
                                @if($form->image)
                                <img src="{{ asset($form->image) }}" alt="User Image" data-toggle="modal"
                                    data-target="#imageModal{{ $form->id }}">
                                @else
                                No Image
                                @endif
                            </td>

                            <td class="website" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top"
                                title="@if($form->website) {{ $form->website }} @else No Website @endif">
                                @if($form->website)
                                <a href="{{ $form->website }}" target="_blank">{{ $form->website }}</a>
                                @else
                                No Website
                                @endif
                            </td>

                            <td class="number" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->number }}">
                                {{ $form->number }}</td>

                            <td class="budget" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->budget }}">
                                {{ $form->budget }}</td>

                            <td class="date" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->date }}">
                                {{ $form->date }}</td>

                            <td class="hobbies" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top"
                                title="{{ is_array($form->hobbies) ? implode(', ', $form->hobbies) : $form->hobbies }}">
                                {{ is_array($form->hobbies) ? implode(', ', $form->hobbies) : $form->hobbies }}</td>

                            <td class="country_id" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->country_name }}">
                                {{ $form->country_name }}</td>

                            <td class="state_id" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->state_name  }}">
                                {{ $form->state_name }}</td>

                            <td class="city_id" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->city_name }}">
                                {{ $form->city_name }}</td>

                            <td class="gender" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->gender }}">
                                {{ $form->gender }}</td>

                            <td class="address" style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;"
                                data-toggle="tooltip" data-placement="top" title="{{ $form->address }}">
                                {{ $form->address }}</td>

                            <td class="action-btns">
                                <a href="{{ route('form.add', ['id' => $form->id]) }}" title="Edit">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                                <form action="{{ route('form.delete', ['id' => $form->id]) }}" method="POST"
                                    style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" title="Delete"
                                        onclick="return confirm('Are you sure you want to delete this item?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                        @else
                        <tr>
                            <td colspan="12" class="text-center">No records found</td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @foreach ($forms as $form)
    @if($form->image)
    <div class="modal fade" id="imageModal{{ $form->id }}" tabindex="-3" role="dialog"
        aria-labelledby="imageModalLabel{{ $form->id }}" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-dark" id="imageModalLabel{{ $form->id }}"> Image Preview
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img src="{{ asset($form->image) }}" alt="User Image" class="img-fluid">
                </div>

            </div>
        </div>
    </div>
    @endif
    @endforeach

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip({
                boundary: 'viewport',
                container: 'body'
            });
        });
    </script>
</body>

</html>