<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Form extends Model
{
    protected $fillable = [
        'name', 'website', 'number', 'image', 'budget', 'date', 'gender','address','password','hobbies','country_id','state_id','city_id'
    ];

    protected $casts = [
        'hobbies' => 'array',
    ];


}
