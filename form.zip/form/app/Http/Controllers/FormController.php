<?php

namespace App\Http\Controllers;

use App\Models\Form;

use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Support\ValidatedData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FormController extends Controller
   { public function add($id = null){
        $form = $id ? Form::findOrFail($id) : null;
        $countries = DB::table('countries')->orderBy('name', 'ASC')->get();
        $states = $form ? DB::table('states')->where('country_id', $form->country_id)->orderBy('name', 'ASC')->get() : [];
        $cities = $form ? DB::table('cities')->where('state_id', $form->state_id)->orderBy('name', 'ASC')->get() : [];
        return view('form.add', compact('form', 'countries', 'states', 'cities'));
    }

    public function getStates($country_id)
{
    $states = DB::table('states')->where('country_id', $country_id)->orderBy('name', 'ASC')->get();
    return response()->json(['states' => $states]);
}

public function getCities($state_id)
{
    $cities = DB::table('cities')->where('state_id', $state_id)->orderBy('name', 'ASC')->get();
    return response()->json(['cities' => $cities]);
}


    public function store(Request $request, $id = null){
        $validatedData = $request->validate([
            'name' => 'required|string',
            'website' => 'nullable|url',
            'number' => 'required|numeric|digits:10',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'budget' => 'required|integer|min:0|max:100000',
            'date' => 'required|date',
            'hobbies' => 'nullable|array',
            'gender' => 'required|string',
            'country_id' => 'required|string',
            'state_id' => 'required|string',
            'city_id' => 'required|string',
            'address' => 'required|string',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $form = $id ? Form::findOrFail($id) : new Form();
        if($request->hasFile('image'))
            {
                $image = $request->file('image');
                $original=strtotime(now()).'-'.random_int(10000, 99999).'.'.$image->getClientOriginalExtension();
                $pathname=public_path().'/image/user_profile';
                $photo_path='image/user_profile/'.$original;
                $image->move($pathname, $original);
                $validatedData['image']=$photo_path;
            }
        $form->fill($validatedData);
        $form->name = $request->name;
        $form->website = $request->website;
        $form->number = $request->number;
        $form->date = $request->date;
        $form->hobbies = $request->input('hobbies', []);
        $form->gender = $request->gender;
        $form->country_id = $request->country_id;
        $form->state_id = $request->state_id;
        $form->city_id = $request->city_id;
        $form->address = $request->address;
        $form->budget = $request->budget;
        $form->password = bcrypt($request->password);
        $form->save();

        $message = $id ? 'Details Updated Successfully' : 'Details Registered Successfully';

        return redirect()->route('form.list')->with('success', $message);
    }

    public function list(){
        $forms = DB::table('forms')
            ->leftJoin('countries', 'forms.country_id', '=', 'countries.id')
            ->leftJoin('states', 'forms.state_id', '=', 'states.id')
            ->leftJoin('cities', 'forms.city_id', '=', 'cities.id')
            ->select('forms.*', 'countries.name as country_name', 'states.name as state_name', 'cities.name as city_name')
            ->orderBy('forms.created_at', 'DESC')
            ->get();

        return view('form.list', compact('forms'));
    }

    public function delete($id){
        $form = Form::findOrFail($id);
        $form->delete();
        return redirect()->route('form.list')->with('success', 'Details Deleted Successfully');
    }

}
